<html>
<head>  
<?php include("connect.php")?>  
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>FLIGHT BOOKING SYSTEM</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body style="background-image: url('images/aero2.jpg');background-repeat:no-repeat;background-size:cover;">


<center><h3 style="color:white;font-size:35px;margin: 80px 220px;">REGISTER </h3>
</center>
<div style="width:500px;background: rgba(255, 255, 255, 0.3);height:400px;padding:50px;margin:auto;border-radius:30px;" >
<form action="register_process.php" method="post">
<label>Enter your User ID</label>
<div class="form-floating mb-3">
  <input type="text" required class="form-control" name="username" id="floatingInput" placeholder="User Name">
  <label for="floatingInput">User ID</label>
</div><br>
<label>Enter your Password</label>
<div class="form-floating">
  <input type="password" required class="form-control" name="password" id="floatingPassword" placeholder="Password">
  <label for="floatingPassword">Password</label>
</div><br><br>
<center>
<input type="submit" name="submit" value="SUBMIT" class="btn btn-light" ></center>
<a href="index.php"><button type="button" class="btn btn-outline-dark" >Back</button></a>
</form>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>