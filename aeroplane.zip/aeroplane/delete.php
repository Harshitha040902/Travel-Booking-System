


<?php
 include("connect.php");
$username = $_GET['username'];
$query1=mysqli_query($con,"DELETE FROM `passenger` WHERE `username`='$username'");
 $query2=mysqli_query($con,"DELETE FROM `ticket` WHERE `username`='$username'");
 $query3=mysqli_query($con,"INSERT INTO `passenger`(`username`) VALUES ('$username')");
 $query4=mysqli_query($con,"INSERT INTO `ticket`(`username`) VALUES ('$username')");
if($query1 and $query2 and $query3 and $query4){
	
	 echo"<script>alert('Deletion is successful');window.location.assign('welcome.php');</script>";
}else{
	 echo"<script>alert('Deletion Failed');window.location.assign('my_booking.php');</script>";
}

?>