<?php
session_start();
require('connect.php');

$ticket_id = mysqli_real_escape_string($con, $_POST['ticket_id']);
$username = $_SESSION['username'];

$query = "SELECT * FROM `ticket` WHERE `username`='$username' and `ticket_id`='$ticket_id'";
$result = mysqli_query($con, $query);

if ($result) {
    if(mysqli_num_rows($result) == 1) {
        echo '<script>alert("Welcome");window.location.assign("my_booking.php");</script>';
    } else {
        echo '<script>alert("Incorrect Ticket ID");window.location.assign("welcome.php");</script>';
    }
} else {
    // Handle query execution error
    echo "Error executing query: " . mysqli_error($con);
}

mysqli_close($con);
?>
