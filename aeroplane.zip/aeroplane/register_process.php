<?php
   include("connect.php");
   if (isset($_POST['submit'])) {
       $username = $_POST['username'];
       $password = $_POST['password'];
       
       $query    = mysqli_query($con, "SELECT * FROM `user` WHERE `username`='$username'");
       if (mysqli_num_rows($query) == 0) {
           
       
               
               $query1 = mysqli_query($con, "INSERT INTO `user`(`username`, `password`) VALUES ('$username','$password')");
                           $query2 = mysqli_query($con, "INSERT INTO `passenger`(`username`) VALUES ('$username')");
                           $query3 = mysqli_query($con, "INSERT INTO `ticket`(`username`) VALUES ('$username')");
   
               if ($query1 and $query2 and $query3) {
                   echo "<script>alert('Registration successful');window.location.assign('login.php');</script>";
               } else {
                   echo "<script>alert('Registration failed');window.location.assign('register.php');</script>";
               }
           
       } else {
           echo "<script>alert('User ID already exists');window.location.assign('register.php');</script>";
           
       }
       
   }
   
   
   ?>