<html>
   <?php include("head.php")?>  
   <body style="background-image: url('images/aero14.jpg');background-repeat:no-repeat;background-size:cover;">
      <center>
         <h3 style="color:white;font-size:35px;margin: 80px 220px;">Your Ticket Has Been Booked. <br>Enjoy Your Trip!!
		 

		 </h3>
      
	  
	  </center>
      <center>
         <div style="width:80%;background: rgba(171, 178, 185, 0.3);height:300px;padding:25px;margin:50px;border-radius:30px;" >
            <h3 style="color:white;font-size:25px;margin: 20px ;">Details</h3><br>
			
			
            <table class="table table-bordered" style="width:50%;">
               <thead style="text-align:center;">
                  <tr>
                     <th>Flight No</th>
                     <th>Ticket ID</th>
					 <th>Passenger ID</th>
                  </tr>
               </thead>
              <tbody style="text-align:center;">
					<?php
									$i=1;
									$username = $_SESSION['username'];

									$query = mysqli_query($con,"SELECT flight_no , ticket_id , passenger_id FROM `ticket` where `username`='$username'");
									if(mysqli_num_rows($query)>0){
										while($row=mysqli_fetch_array($query)){
											
											$flight_no = $row['flight_no'];
											$ticket_id = $row['ticket_id'];
											$passenger_id = $row['passenger_id'];
											
										?>
               <tr style="color:black;">
                  <td><?php echo $flight_no ?>
                  </td>
                  <td><?php echo $ticket_id ?></td>
                  <td><?php echo $passenger_id ?></td>
                  
               </tr>
               
               <?php
                  $i++;
                  
                  }
                  }
                  else{
                  ?>
               <tr>
                  <td colspan="2">Sorry you have no List.</td>
               </tr>
               <?php
                  }
                  ?></tbody>
            </table>
			
         </div>
		 		 		<a href="welcome.php"><button type="submit" name="submit" class="btn btn-light" style="margin-left: 1000px;" >Back</button></a> 

      </center>
     
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
   </body>
</html>