<?php
$con=mysqli_connect("localhost","root","Harshitham040902#","aero");
/*if (!$con) {
	die("Connection Error".mysqli_connect_error());
} else {
	echo "Database Connection Successfully.";
}*/
?>
