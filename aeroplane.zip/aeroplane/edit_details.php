<html>
   <?php include("head.php")?>  
  <?php
$first_name=$_GET['first_name'];
$last_name=$_GET['last_name'];
$gender=$_GET['gender'];
$mobile=$_GET['mobile'];
$email=$_GET['email'];
$dob=$_GET['dob'];
  ?>
	
   <body style="background-image: url('images/aero4.jpg');background-repeat:no-repeat;background-size:cover;">
      <center>
         <h3 style="color:white;font-size:35px;margin: 40px 220px;">Edit Your Details If Required.
		<a href="welcome.php"><button type="button" class="btn btn-light" style="margin-left: 1000px;" >Back</button></a> 

		</h3>
      </center>
      <div style="width:800px;background: rgba(255, 255, 255, 0.3);height:400px;padding:50px;margin:auto;border-radius:30px;" >
         <form class="row row-cols-lg-auto g-3 align-items-center" action="edit_details.php" method="post">
             <div class="col-lg-6">
				<center><h3 style="color:black;font-size:25px;">First Name : </h3></center>
            </div>
			<div class="col-lg-6">
               <input type="text" style="width:300px; " value="<?php echo $first_name?>" name="first_name" class="form-control" placeholder="First name" aria-label="First name">
            </div>
			<div class="col-lg-6">
				<center><h3 style="color:black;font-size:25px;">Last Name : </h3></center>
            </div>
            <div class="col-lg-6">
               <input type="text" class="form-control"name="last_name" value="<?php echo $last_name?>" style="width:300px; " placeholder="Last name" aria-label="Last name">
            </div>
			<div class="col-lg-6">
				<center><h3 style="color:black;font-size:25px;">Mobile No : </h3></center>
            </div>
            <div class="col-lg-6">
               <input type="text" style="width:300px;" name="mobile" value="<?php echo $mobile?>" class="form-control" placeholder="Mobile No" aria-label="First name">
            </div>
			<div class="col-lg-6">
				<center><h3 style="color:black;font-size:25px;">Email : </h3></center>
            </div>
            <div class="col-lg-6">
               <input type="email" style="width:300px;" name="email"  value="<?php echo $email?>" class="form-control" placeholder="Email ID" aria-label="First name">
            </div>
            
         
          
            <input type="hidden" name="username" value="<?php echo $_SESSION['username']; ?>">

			<div class="col-lg-12">
			  <br>
               <center><input type="submit" name="submit" class="btn btn-primary"></center>
            </div>

         </form>
		 
         <?php
            if (isset($_POST['submit'])) {
                $first_name = $_POST['first_name'];
                $last_name = $_POST['last_name'];
                 $mobile = $_POST['mobile'];
                $email = $_POST['email'];
              
                
            		   $username=mysqli_real_escape_string($con,$_POST['username']);
					  
            		   $query1 = mysqli_query($con, " UPDATE `passenger` SET `first_name`='$first_name',`last_name`='$last_name', `mobile`='$mobile', `email`='$email' WHERE `username`='$username'");
                        if ($query1) {
                            echo "<script>alert('Updated successful');window.location.assign('my_booking.php');</script>";
                        } else {
                            echo "<script>alert('Updation failed');window.location.assign('edit_details.php');</script>";
                        }   
                }
            ?>
      </div>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
   </body>
</html>