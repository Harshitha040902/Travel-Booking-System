<html>
   <?php include("head.php")?>  
  
	
   <body style="background-image: url('images/aero4.jpg');background-repeat:no-repeat;background-size:cover;">
      <center>
         <h3 style="color:white;font-size:35px;margin: 60px 220px;">CONFIRM FLIGHT!

<?php
    // Check if the "flight_no" parameter exists in the URL
    if(isset($_GET['flight_no'])) {
        // The "flight_no" parameter exists
        $flight_no = $_GET['flight_no'];
        // Now you can use $flight_no for further processing
        echo "Flight number: " . $flight_no;
    } else {
        // The "flight_no" parameter does not exist in the URL
        echo "Flight number not Valid.";
    }
?>


		<a href="welcome.php"><button type="button" class="btn btn-light" style="margin-left: 1200px;" >Back</button></a> 
		</h3>
      </center>
      <div style="width:800px;background: rgba(255, 255, 255, 0.3);height:400px;padding:50px;margin:auto;border-radius:30px;" >
         <form class="row row-cols-lg-auto g-3 align-items-center" action="confirm_booking.php" method="post">
            <div class="col-lg-6">
               <input type="text" style="width:300px; " required name="first_name" class="form-control" placeholder="First name" aria-label="First name">
            </div>
            <div class="col-lg-6">
               <input type="text" class="form-control" required name="last_name" style="width:300px; " placeholder="Last name" aria-label="Last name">
            </div>
            <div class="col-lg-6">
               <input type="text" style="width:300px;" required name="mobile" class="form-control" placeholder="Mobile No" aria-label="First name">
            </div>
            <div class="col-lg-6">
               <input type="email" style="width:300px;"required name="email"  class="form-control" placeholder="Email ID" aria-label="First name">
            </div>
            
            <div class="col-lg-6">
               <select class="form-select" required style="width:300px;" name="type" aria-label="Default select example">
                  <option selected>Class</option>
                  <option value="First">First</option>
                  <option value="Economy">Economy</option>
                  <option value="Business">Business</option>
                  <option value="Premium">Premium</option>
               </select>
            </div>
            <br>
            <div class="col-lg-6">
               <div class="form-check form-check-inline">
                  <input class="form-check-input" required type="radio" name="gender" id="inlineRadio1" value="Male">
                  <label class="form-check-label" for="inlineRadio1">Male</label>
               </div>
               <div class="form-check form-check-inline">
                  <input class="form-check-input" required type="radio" name="gender" id="inlineRadio2" value="Female">
                  <label class="form-check-label" for="inlineRadio2">Female</label>
               </div>
            </div>
            <div class="col-lg-6" class="form-floating" style="width:317px;">
               <label for="floatingPassword"> &nbsp; Date Of Birth</label>
               <input type="date" name="dob" required class="form-control" id="floatingPassword" placeholder="Departure Date">
            </div>
            <br>
            <input type="hidden" name="username" value="<?php echo $_SESSION['username']; ?>">

			<div class="col-lg-12">
               <input type="submit" name="submit" class="btn btn-primary">
            </div>
		<input type="hidden" name="flight_no" value="<?php echo $_GET['flight_no']; ?>">

         </form>
		 
         <?php
            if (isset($_POST['submit'])) {
                $first_name = $_POST['first_name'];
                $last_name = $_POST['last_name'];
                 $mobile = $_POST['mobile'];
                $email = $_POST['email'];
                 $type = $_POST['type'];
                $gender = $_POST['gender'];
                     $dob = $_POST['dob'];
                $ticket_id=rand(3500,4000);
                       $passenger_id=rand(1,50); 
            		   $username=mysqli_real_escape_string($con,$_POST['username']);
					   $flight_no=mysqli_real_escape_string($con,$_POST['flight_no']);
            		   $query1 = mysqli_query($con, " UPDATE `passenger` SET `passenger_id`='$passenger_id',`first_name`='$first_name', `last_name`='$last_name',`gender`='$gender',`dob`='$dob', `mobile`='$mobile',`email`='$email' WHERE `username`='$username'");
                       $query2=mysqli_query($con," UPDATE `ticket` SET `ticket_id`='$ticket_id',`passenger_id`='$passenger_id',`flight_no`='$flight_no', `type`='$type' WHERE `username`='$username'");
                        if ($query1 and $query2) {
                            echo "<script>alert('Booking successful');window.location.assign('details.php');</script>";
                        } else {
                            echo "<script>alert('Booking failed');window.location.assign('book_flights.php');</script>";
                        }   
                }
            ?>
      </div>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
   </body>
</html>