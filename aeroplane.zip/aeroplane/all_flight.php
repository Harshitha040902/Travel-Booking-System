<html>
   <?php include("head.php")?>  
   
   <body style="background-color:#BD1606;">
      <center>
         <h3 style="color:white;font-size:35px;margin: 20px 220px;">All Flights !<a href="welcome.php"><button type="button" class="btn btn-light" style="margin-left: 1200px;" >Back</button></a></h3>
      </center>
      <center>
         <div style="width:80%;background: rgba(249, 235, 234, 0.3);height:1100px;padding:25px;margin:50px;border-radius:30px;" >
            <h3 style="color:white;font-size:25px;margin: 20px ;">Departure Flights</h3>
            <table class="table table-bordered" >
               <thead>
                  <tr>
                     <th>Flight No</th>
                     <th>Type</th>
                     <th>Origin</th>
                     <th>Destination</th>
                     <th>Departure Time</th>
                     <th>Arrival Time</th>
					 <th>Price</th>
                     
                  </tr>
               </thead>
               <?php
                  $i=1;
                  
                  $query = mysqli_query($con,"SELECT * FROM `flight`  ");
                  if(mysqli_num_rows($query)>0){
                  	while($row=mysqli_fetch_array($query)){
                  		
                  		$flight_no = $row['flight_no'];
                  		$type = $row['type'];
                  		$origin = $row['origin'];
                  		$destination = $row['destination'];
                  		$departure_time = $row['departure_time'];
                  		$arrival_time = $row['arrival_time'];
						$price = $row['price'];
                  		
                  		
                  		
                  	?>
               <tr style="color:black;">
                  <td><?php echo $flight_no ?>
                  </td>
                  <td><?php echo $type ?></td>
                  <td><?php echo $origin ?></td>
                  <td><?php echo $destination ?></td>
                  <td><?php echo $departure_time ?></td>
                  <td><?php echo $arrival_time ?></td>
				  <td><?php echo $price ?></td>
                 
               </tr>
               
               <?php
                  $i++;
                  
                  }
                  }
                  else{
                  ?>
               <tr>
                  <td colspan="2">Sorry you have no List.</td>
               </tr>
               <?php
                  }
                  ?>
				 
            </table>
         </div>
		  
      </center>
	 
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
   </body>
</html>