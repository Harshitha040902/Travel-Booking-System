<html>
   <?php include("head.php")?>  
  
   <body style="background-image: url('images/aero3.jpg');background-repeat:no-repeat;background-size:cover;">
      
         <h3 style="color:white;font-size:35px;margin: 20px ;"><a href="logout.php"><label style="font-size:20px;color:white;" ><u>Logout</u></label></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Your Experience Starts Here!&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="all_flight.php"><label style="font-size:18px;color:white;" ><u>All Flights</u></label></a> 
		</h3>
      
	   
	  
      <div class="row" >
         <div style="width:400px;background: rgba(174, 182, 191, 0.5);height:520px;padding:25px;margin:50px;border-radius:30px;" >
            <center>
               <h3 style="color:black;font-size:25px;">SEARCH FLIGHTS</h3>
            </center>
            <br>
            <form action="book_flights.php" method="post">
               <center>
                  <select class="form-select" name="origin" required style="width:80%;" aria-label="Default select example">
                     <option selected>Origin</option>
                     <option value="Delhi">Delhi</option>
                     <option value="Bangalore">Bangalore</option>
                     <option value="Mumbai">Mumbai</option>
                     <option value="Kolkata">Kolkata</option>
                  </select>
               </center>
               <br>
               <center>
                  <select class="form-select" required style="width:80%;" name="destination" aria-label="Default select example">
                     <option selected>Destination</option>
                     <option value="Delhi">Delhi</option>
                     <option value="Bangalore">Bangalore</option>
                     <option value="Mumbai">Mumbai</option>
                     <option value="Kolkata">Kolkata</option>
                  </select>
               </center>
               <br>
               <center>
                  <div class="form-floating" style="width:80%;">
                     <input type="text" name="passengers" required class="form-control" id="floatingPassword" placeholder="No Of Passengers">
                     <label for="floatingPassword">No Of Passengers</label>
                  </div>
               </center>
               <br>
               <center>
                  <div class="form-floating" style="width:80%;">
                     <input type="date" name="departure_date" required class="form-control" id="floatingPassword" placeholder="Departure Date">
                     <label for="floatingPassword">Departure Date</label>
                  </div>
               </center>
               <br>
               <center>
                  <div class="form-floating" style="width:80%;">
                     <input type="date" name="return_date" required class="form-control" id="floatingPassword" placeholder="Return Date">
                     <label for="floatingPassword">Return Date</label>
                  </div>
               </center>
               <br>
               <center>
                  <input type="submit" name="submit" value="SEARCH" class="btn btn-light" >
               </center>
            </form>
         </div>
         <div style="width:400px;background: rgba(174, 182, 191, 0.5);height:400px;padding:25px;margin:50px;border-radius:30px;" >
            <center>
               <h3 style="color:black;font-size:25px;">MY BOOKINGS</h3>
            </center>
            <br><br><br>
            <form action="my_booking_process.php" method="post">
               <center>
                  <div class="form-floating" style="width:80%;">
                     <input type="text" name="ticket_id" required class="form-control" id="floatingPassword" placeholder="Ticket Number">
                     <label for="floatingPassword">Ticket Number</label>
                  </div>
               </center>
               <br>
              
               <br>
               <center>
                 <input type="submit" name="submit" value="SUBMIT" class="btn btn-light" >
               </center>
            </form>
		

         </div>
         <div style="width:400px;background: rgba(174, 182, 191, 0.5);height:400px;padding:25px;margin:50px;border-radius:30px;" >
            <center>
               <h3 style="color:black;font-size:25px;">FLIGHT DETAILS</h3>
            </center>
            <form action="flight_details_process.php" method="post">
               <br><br><br>
               <center>
                  <div class="form-floating" style="width:80%;">
                     <input type="text" name="flight_no" required class="form-control" id="floatingPassword" placeholder="Flight Number">
                     <label for="floatingPassword">Flight Number</label><br>
                  </div>
               </center>
          
               <br>
               <center>
                  <input type="submit" name="submit" value="SUBMIT" class="btn btn-light" >
               </center>
            </form>
         </div>
      </div>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
   </body>
</html>