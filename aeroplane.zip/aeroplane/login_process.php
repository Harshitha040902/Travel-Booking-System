<?php
session_start();
require('connect.php');
$username = mysqli_real_escape_string($con,$_POST['username']);
$password = mysqli_real_escape_string($con,$_POST['password']);

$query=mysqli_query($con,"SELECT * FROM `user` WHERE `username`='$username'");
$row=mysqli_fetch_array($query);
$my_username=$row['username'];
$my_password=$row['password'];

	if($username==$my_username){
	    if($password==$my_password){
    	$_SESSION['username'] = $username;
		$_SESSION['id'] = session_id();
		$_SESSION['login_type'] = "user";
	
	echo '<script>alert("LOGIN SUCCESSFUL.");window.location.assign("welcome.php");</script>';

  

}else{
    echo '<script>alert("YOUR PASSWORD IS WORNG PLEASE TRY AGAIN. THANK YOU.");window.location.assign("index.php");</script>';
}
}else{
	echo '<script>alert("YOUR USERNAME IS WORNG PLEASE TRY AGAIN. THANK YOU.");window.location.assign("index.php");</script>';
}

?>