<html>
   <?php include("head.php")?>  
   <body style="background-image: url('images/aero9.jpg');background-repeat:no-repeat;background-size:cover;">
      <center>
         <h3 style="color:white;font-size:35px;margin: 80px 220px;">Your Ticket 
		<a href="welcome.php"><button type="button" class="btn btn-light" style="margin-left: 1000px;" >Back</button></a> 

		 </h3>
      </center>
      <center>
         <div style="width:80%;background: rgba(247, 249, 249, 0.5);height:300px;padding:25px;margin:50px;border-radius:30px;" >
 
			<br><br>
			
            <table class="table table-bordered" style="width:100%;">
               <thead style="text-align:center;">
                  <tr>
                     
                     <th>Ticket ID</th>
					 <th>Flight No</th>
					  <th>Passenger ID</th>
					  <th>Class</th>
					 <th>First Name</th>
					 <th>Last Name</th>
					   <th>Gender</th>
					   <th>Mobile</th>
					   <th>Email</th>
					   <th>DOB</th>
					  <th>Edit</th>
					  <th>Delete</th>
                  </tr>
               </thead>
              <tbody style="text-align:center;">
					<?php
									$i=1;
									$username = $_SESSION['username'];

									$query1 = mysqli_query($con,"SELECT flight_no , ticket_id, type, passenger_id FROM `ticket` where `username`='$username'");

									if(mysqli_num_rows($query1)>0){
										while($row=mysqli_fetch_array($query1)){
											
											$flight_no = $row['flight_no'];
											$ticket_id = $row['ticket_id'];
											$type = $row['type'];
											$passenger_id = $row['passenger_id'];
									$query = mysqli_query($con,"SELECT first_name , last_name, mobile, email,gender,dob FROM `passenger` where `username`='$username'");

											
									if(mysqli_num_rows($query)>0){
										while($row=mysqli_fetch_array($query)){
											
											
											$first_name = $row['first_name'];
											$last_name = $row['last_name'];
											
											$mobile = $row['mobile'];
											$email = $row['email'];
											$gender = $row['gender'];
											$dob = $row['dob'];
											
											
										?>
               <tr style="color:black;">
                  <td><?php echo $ticket_id ?></td>
				   <td><?php echo $flight_no ?></td>
                  <td><?php echo $passenger_id ?></td>
				   <td><?php echo $type ?></td>
                  <td><?php echo $first_name ?></td>
				   <td><?php echo $last_name ?></td>
                  <td><?php echo $gender ?></td>
				   <td><?php echo $mobile ?></td>
                  <td><?php echo $email ?></td>
				  <td><?php echo $dob ?></td>
				  <td>
                     <a href="edit_details.php?first_name=<?php echo $first_name;?> & last_name=<?php echo $last_name;?> & gender=<?php echo $gender;?> & mobile=<?php echo $mobile;?> & email=<?php echo $email;?> & dob=<?php echo $dob;?>">
                        <input type="submit" name="submit" class="btn btn-success" value="EDIT">
                     </a>
                  </td>
                  <td>
                     <a href="delete.php?username=<?php echo $username;?>">
                        <input type="submit" name="submit" class="btn btn-success" value="DELETE">
                     </a>
                  </td>
                  
               </tr>
               
               <?php
                  $i++;
										}
									}
                  }
                  }
                  else{
                  ?>
               <tr>
                  <td colspan="2">Sorry you have no List.</td>
               </tr>
               <?php
                  }
                  ?></tbody>
            </table>
         </div>
      </center>
     
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
   </body>
</html>